﻿$(function () {
    gdo.consoleOut('.$projectname$', 1, 'Loaded $projectname$ JS');
    $.connection.$projectname$AppHub.client.receiveName = function (instanceId, name) {
        if (gdo.clientMode == gdo.CLIENT_MODE.CONTROL) {
            gdo.consoleOut('.$projectname$', 1, 'Instance - ' + instanceId + ": Received Name : " + name);
        } else if (gdo.clientMode == gdo.CLIENT_MODE.NODE) {
            gdo.consoleOut('.$projectname$', 1, 'Instance - ' + instanceId + ": Received Name : " + name);
            $("iframe").contents().find("#hello_text").empty().append("Hello " + name);
        }
    }
});

gdo.net.app["$projectname$"].initClient = function () {
    gdo.consoleOut('.$projectname$', 1, 'Initializing $projectname$ App Client at Node ' + gdo.clientId);
}

gdo.net.app["$projectname$"].initControl = function () {
    gdo.controlId = getUrlVar("controlId");
    gdo.net.app["$projectname$"].server.requestName(gdo.controlId);
    gdo.consoleOut('.$projectname$', 1, 'Initializing $projectname$ App Control at Instance ' + gdo.controlId);

    $("iframe").contents().find("#hello_submit")
    .unbind()
    .click(function () {
        gdo.consoleOut('.$projectname$', 1, 'Sending Name to Clients :' + $("iframe").contents().find('#hello_input').val());
        gdo.net.app["$projectname$"].server.setName(gdo.controlId, $("iframe").contents().find('#hello_input').val());
    });
}

gdo.net.app["$projectname$"].terminateClient = function () {
    gdo.consoleOut('.$projectname$', 1, 'Terminating $projectname$ App Client at Node ' + clientId);
}

gdo.net.app["$projectname$"].ternminateControl = function () {
    gdo.consoleOut('.$projectname$', 1, 'Terminating $projectname$ App Control at Instance ' + gdo.controlId);
}
